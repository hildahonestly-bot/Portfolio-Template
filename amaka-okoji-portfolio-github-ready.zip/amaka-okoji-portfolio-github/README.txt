GitHub-ready version of the approved Amaka Okoji portfolio.

Structure:
- index.html
- assets/

The HTML structure, CSS, JavaScript, content, image bytes, and responsive rules are preserved. 
Only the embedded Base64 image sources were extracted into local assets and their src paths updated.
